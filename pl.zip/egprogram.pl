clear()
setScreen(800,600,32)
println "Hello World!"
terminate()